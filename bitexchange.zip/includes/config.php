<?php
	$CONF = array();
	$CONF["host"] = "localhost";
	$CONF["user"] = "adnanhab_habib";
	$CONF["pass"] = "j48vzY2UA2c7xNL";
	$CONF["name"] = "adnanhab_habib";
	?>